import os

import numpy as np
import pybsnn_cpp


class BSNNLite:
  def __init__(self, model_dir, verbose=False):
    """
    Initialize BSNN Model
    :param model_dir: Directory containing .meta, .lib, and weights files
    :param verbose: Enable verbose logging
    """
    if model_dir is None:
      raise ValueError("model_dir cannot be None")
    if not isinstance(model_dir, str) or not model_dir.strip():
      raise ValueError("model_dir must be a non-empty string")
    if not os.path.isdir(model_dir):
      raise FileNotFoundError(f"Model directory not found: {model_dir}")

    self.model_dir = model_dir
    self.verbose = verbose
    self.model = None
    self._destroyed = False

    try:
      self.model = pybsnn_cpp.Model(model_dir)
      if not self.model.is_valid():
        raise RuntimeError("Failed to load BSNN model")
    except Exception:
      self.model = None
      raise

  def _ensure_active(self, action="operation"):
    if self._destroyed or self.model is None:
      raise RuntimeError(f"Model not initialized or already destroyed; cannot {action}")

  @staticmethod
  def _validate_input_tensor(tensor, index):
    if not isinstance(tensor, np.ndarray):
      raise ValueError(
          f"Input tensor {index} must be a numpy.ndarray, got {type(tensor).__name__}")
    if tensor.dtype != np.uint8:
      raise ValueError(f"Input tensor {index} must be uint8, got {tensor.dtype}")
    if tensor.size == 0:
      raise ValueError(f"Input tensor {index} cannot be empty")
    if not tensor.flags["C_CONTIGUOUS"]:
      raise ValueError(f"Input tensor {index} must be C-contiguous")

  def init_runtime(self):
    """
    Initialize the runtime environment.
    In this implementation, it's already handled by the constructor but kept for API consistency.
    """
    self._ensure_active("initialize runtime")
    if not self.model.is_valid():
      raise RuntimeError("Model not loaded yet")
    return 0

  def inference(self, inputs):
    """
    Run model inference
    :param inputs: Input data as a list of NumPy arrays or a single 4D array for batch.
    :return: List of outputs (each output is a list of NumPy arrays if batch > 1)
    """
    self._ensure_active("run inference")

    if inputs is None:
      raise ValueError("Inference inputs cannot be None")

    if isinstance(inputs, (list, np.ndarray)) and len(inputs) == 0:
      raise ValueError("Inference inputs cannot be empty")

    formatted_inputs = []

    if isinstance(inputs, np.ndarray):
      if inputs.ndim < 2:
        raise ValueError("Batch ndarray must have at least 2 dimensions")
      for b in range(inputs.shape[0]):
        formatted_inputs.append([inputs[b]])
    elif isinstance(inputs, list):
      if all(isinstance(i, np.ndarray) for i in inputs):
        input_count = self.model.get_input_count()
        if len(inputs) == input_count:
          formatted_inputs.append(inputs)
        else:
          for item in inputs:
            formatted_inputs.append([item])
      elif all(isinstance(i, list) for i in inputs):
        formatted_inputs = inputs
      else:
        raise ValueError("Invalid list input. Expected list of ndarrays or list of lists.")
    else:
      raise ValueError(
          f"Unsupported input type: {type(inputs).__name__}. Expected ndarray or list of ndarrays.")

    if not formatted_inputs:
      raise ValueError("No valid input tensors provided for inference")

    input_count = self.model.get_input_count()
    for batch_idx, batch_item in enumerate(formatted_inputs):
      if not isinstance(batch_item, list):
        raise ValueError(f"Batch item {batch_idx} must be a list of ndarrays")
      if len(batch_item) != input_count:
        raise ValueError(
            f"Batch item {batch_idx} has {len(batch_item)} inputs, but model requires {input_count}")
      for input_idx, tensor in enumerate(batch_item):
        self._validate_input_tensor(tensor, input_idx)

    try:
      results = self.model.inference(formatted_inputs)
    except ValueError:
      raise
    except Exception as exc:
      raise RuntimeError(f"Inference failed: {exc}") from exc

    if len(results) == 1:
      return results[0]
    return results

  def destroy(self):
    """Explicitly release model resources."""
    if self.model is not None:
      self.model.destroy()
      self.model = None
    self._destroyed = True

  def __del__(self):
    if getattr(self, "model", None) is not None:
      self.destroy()
